"""
Shared Pydantic models used across Hospital, Laboratory and Pharmacy services.
These define the data contracts for inter-service communication.
"""

from datetime import datetime
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


# ---------- Enums ----------

class TestStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class PrescriptionStatus(str, Enum):
    RECEIVED = "received"
    VALIDATED = "validated"
    DISPENSED = "dispensed"
    REJECTED = "rejected"


class ConsultationStatus(str, Enum):
    OPEN = "open"
    AWAITING_LAB = "awaiting_lab"
    LAB_COMPLETE = "lab_complete"
    PRESCRIBED = "prescribed"
    CLOSED = "closed"


# ---------- Patient ----------

class PatientBase(BaseModel):
    first_name: str
    last_name: str
    date_of_birth: str          # YYYY-MM-DD
    gender: str
    phone: Optional[str] = None
    national_id: Optional[str] = None


class PatientCreate(PatientBase):
    pass


class Patient(PatientBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Laboratory ----------

class TestItem(BaseModel):
    test_code: str
    test_name: str
    notes: Optional[str] = None


class LabOrderCreate(BaseModel):
    consultation_id: int
    patient_id: int
    patient_name: str
    tests: List[TestItem]
    ordered_by: str
    priority: str = "normal"    # normal | urgent


class LabOrder(LabOrderCreate):
    id: int
    status: TestStatus = TestStatus.PENDING
    created_at: datetime
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class TestResultItem(BaseModel):
    test_code: str
    test_name: str
    result_value: str
    unit: Optional[str] = None
    reference_range: Optional[str] = None
    flag: Optional[str] = None  # H / L / N


class LabResult(BaseModel):
    order_id: int
    results: List[TestResultItem]
    performed_by: str
    comments: Optional[str] = None
    completed_at: datetime


# ---------- Pharmacy ----------

class MedicationItem(BaseModel):
    drug_code: str
    drug_name: str
    dosage: str
    frequency: str
    duration: str
    quantity: int
    instructions: Optional[str] = None


class PrescriptionCreate(BaseModel):
    consultation_id: int
    patient_id: int
    patient_name: str
    medications: List[MedicationItem]
    prescribed_by: str
    diagnosis: Optional[str] = None


class Prescription(PrescriptionCreate):
    id: int
    status: PrescriptionStatus = PrescriptionStatus.RECEIVED
    created_at: datetime
    dispensed_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# ---------- Hospital Consultation ----------

class ConsultationCreate(BaseModel):
    patient_id: int
    doctor_name: str
    chief_complaint: str
    notes: Optional[str] = None


class Consultation(ConsultationCreate):
    id: int
    status: ConsultationStatus = ConsultationStatus.OPEN
    lab_order_id: Optional[int] = None
    prescription_id: Optional[int] = None
    diagnosis: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Inter-service response wrappers ----------

class ServiceResponse(BaseModel):
    success: bool
    message: str
    data: Optional[dict] = None
