from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

SQLALCHEMY_DATABASE_URL = "sqlite:///./laboratory.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class LabOrderModel(Base):
    __tablename__ = "lab_orders"

    id = Column(Integer, primary_key=True, index=True)
    consultation_id = Column(Integer, nullable=False)
    patient_id = Column(Integer, nullable=False)
    patient_name = Column(String, nullable=False)
    tests = Column(JSON, nullable=False)          # list of test dicts
    ordered_by = Column(String, nullable=False)
    priority = Column(String, default="normal")
    status = Column(String, default="pending")
    results = Column(JSON, nullable=True)         # list of result dicts
    performed_by = Column(String, nullable=True)
    comments = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
