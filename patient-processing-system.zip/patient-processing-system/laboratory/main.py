"""
Laboratory Service – Port 8002
Receives test orders from Hospital, allows completion of tests,
and returns results.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List, Optional

from database import init_db, get_db, LabOrderModel
from shared.models import (
    LabOrderCreate, LabOrder, LabResult, TestResultItem,
    TestStatus, ServiceResponse
)

app = FastAPI(
    title="Laboratory Service",
    description="Receive test orders, perform tests, return results",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    init_db()


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------
@app.post("/orders", response_model=LabOrder, status_code=status.HTTP_201_CREATED)
def create_order(order: LabOrderCreate, db: Session = Depends(get_db)):
    db_order = LabOrderModel(
        consultation_id=order.consultation_id,
        patient_id=order.patient_id,
        patient_name=order.patient_name,
        tests=[t.model_dump() for t in order.tests],
        ordered_by=order.ordered_by,
        priority=order.priority,
        status=TestStatus.PENDING.value
    )
    db.add(db_order)
    db.commit()
    db.refresh(db_order)

    return LabOrder(
        id=db_order.id,
        consultation_id=db_order.consultation_id,
        patient_id=db_order.patient_id,
        patient_name=db_order.patient_name,
        tests=order.tests,
        ordered_by=db_order.ordered_by,
        priority=db_order.priority,
        status=TestStatus(db_order.status),
        created_at=db_order.created_at,
        completed_at=db_order.completed_at
    )


@app.get("/orders", response_model=List[LabOrder])
def list_orders(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    rows = db.query(LabOrderModel).offset(skip).limit(limit).all()
    result = []
    for r in rows:
        result.append(LabOrder(
            id=r.id,
            consultation_id=r.consultation_id,
            patient_id=r.patient_id,
            patient_name=r.patient_name,
            tests=r.tests,
            ordered_by=r.ordered_by,
            priority=r.priority,
            status=TestStatus(r.status),
            created_at=r.created_at,
            completed_at=r.completed_at
        ))
    return result


@app.get("/orders/{order_id}", response_model=LabOrder)
def get_order(order_id: int, db: Session = Depends(get_db)):
    r = db.query(LabOrderModel).filter(LabOrderModel.id == order_id).first()
    if not r:
        raise HTTPException(status_code=404, detail="Order not found")
    return LabOrder(
        id=r.id,
        consultation_id=r.consultation_id,
        patient_id=r.patient_id,
        patient_name=r.patient_name,
        tests=r.tests,
        ordered_by=r.ordered_by,
        priority=r.priority,
        status=TestStatus(r.status),
        created_at=r.created_at,
        completed_at=r.completed_at
    )


# ---------------------------------------------------------------------------
# Complete tests & attach results
# ---------------------------------------------------------------------------
@app.post("/orders/{order_id}/complete", response_model=ServiceResponse)
def complete_order(
    order_id: int,
    results: List[TestResultItem],
    performed_by: str = "Lab Tech",
    comments: Optional[str] = None,
    db: Session = Depends(get_db)
):
    order = db.query(LabOrderModel).filter(LabOrderModel.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    if order.status == TestStatus.COMPLETED.value:
        raise HTTPException(status_code=400, detail="Order already completed")

    order.results = [r.model_dump() for r in results]
    order.performed_by = performed_by
    order.comments = comments
    order.status = TestStatus.COMPLETED.value
    order.completed_at = datetime.utcnow()
    db.commit()

    return ServiceResponse(
        success=True,
        message="Laboratory order completed and results recorded",
        data={
            "order_id": order.id,
            "status": order.status,
            "completed_at": order.completed_at.isoformat()
        }
    )


@app.get("/results/{order_id}", response_model=LabResult)
def get_results(order_id: int, db: Session = Depends(get_db)):
    order = db.query(LabOrderModel).filter(LabOrderModel.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order.status != TestStatus.COMPLETED.value:
        raise HTTPException(status_code=400, detail="Results not yet available")

    return LabResult(
        order_id=order.id,
        results=[TestResultItem(**r) for r in order.results],
        performed_by=order.performed_by,
        comments=order.comments,
        completed_at=order.completed_at
    )


# ---------------------------------------------------------------------------
# Health & root
# ---------------------------------------------------------------------------
@app.get("/")
def root():
    return {
        "service": "Laboratory Service",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
