# Patient Processing System – Integrative Programming Technologies (CSC411)

**University of Eswatini – Department of Computer Science**  
**Course:** Integrative Programming Technologies (CSC411)  
**Assignment:** Mini Project – Process Automation  
**Technology Stack:** Python + FastAPI (REST), SQLite, HTML/JS client  

## Overview

This project demonstrates an **inter-organizational process automation** solution for a **Patient Processing System**.  

Multiple independent organisations collaborate via REST APIs to process a patient from consultation through diagnosis to medication dispensing:

| Organisation     | Role                                      | Port  |
|------------------|-------------------------------------------|-------|
| **Hospital**     | Patient registration, consultations, ordering tests & prescriptions | 8001 |
| **Laboratory**   | Receive test orders, perform tests, return results | 8002 |
| **Pharmacy**     | Receive prescriptions, check stock, dispense medication | 8003 |

### High-level Process Flow
1. Patient is registered / arrives at Hospital.
2. Doctor creates a consultation and orders laboratory tests.
3. Hospital sends test order to Laboratory service (REST).
4. Laboratory processes the order and returns results to Hospital.
5. Doctor reviews results, makes diagnosis and issues a prescription.
6. Hospital sends prescription to Pharmacy service (REST).
7. Pharmacy validates, reserves stock and confirms dispensing.

## Project Structure

```
patient-processing-system/
├── hospital/               # Hospital microservice (FastAPI)
├── laboratory/             # Laboratory microservice (FastAPI)
├── pharmacy/               # Pharmacy microservice (FastAPI)
├── shared/                 # Shared Pydantic models & utilities
├── client/                 # Simple web demo UI
├── docs/                   # Architecture notes, DFDs, diagrams
├── postman/                # Postman collection
├── scripts/                # Helper scripts (start all, seed data)
├── requirements.txt
├── docker-compose.yml      # Optional – run everything with Docker
└── README.md
```

## Quick Start (Local Development)

### Prerequisites
- Python 3.10+
- pip

### 1. Install dependencies
```bash
cd patient-processing-system
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Start the three services (three terminals)

**Terminal 1 – Hospital**
```bash
cd hospital
uvicorn main:app --reload --port 8001
```

**Terminal 2 – Laboratory**
```bash
cd laboratory
uvicorn main:app --reload --port 8002
```

**Terminal 3 – Pharmacy**
```bash
cd pharmacy
uvicorn main:app --reload --port 8003
```

### 3. Open the demo UI
Open `client/index.html` in a browser (or serve it with any static server).

Alternatively use the interactive API docs:
- Hospital:   http://localhost:8001/docs
- Laboratory: http://localhost:8002/docs
- Pharmacy:   http://localhost:8003/docs

## API Overview (Key Endpoints)

### Hospital (port 8001)
- `POST /patients` – Register patient
- `GET  /patients/{id}` – Get patient
- `POST /consultations` – Create consultation
- `POST /consultations/{id}/order-tests` – Order lab tests (calls Laboratory)
- `POST /consultations/{id}/prescribe` – Issue prescription (calls Pharmacy)
- `GET  /consultations/{id}` – Full consultation status

### Laboratory (port 8002)
- `POST /orders` – Receive test order from Hospital
- `GET  /orders/{id}` – Get order status
- `POST /orders/{id}/complete` – Mark tests complete & attach results
- `GET  /results/{order_id}` – Retrieve results

### Pharmacy (port 8003)
- `POST /prescriptions` – Receive prescription from Hospital
- `GET  /prescriptions/{id}` – Get prescription status
- `POST /prescriptions/{id}/dispense` – Dispense medication
- `GET  /stock` – View current stock

## Running the End-to-End Demo

1. Register a patient at the Hospital.
2. Create a consultation.
3. Order laboratory tests → Hospital automatically calls Laboratory.
4. Complete the tests in Laboratory (simulate results).
5. Doctor issues a prescription → Hospital calls Pharmacy.
6. Pharmacy dispenses the medication.

A ready-made Postman collection is provided in `postman/`.

## Design Decisions (for the report)

- **Architecture:** Microservices (each organisation = independent FastAPI service)
- **Communication:** Synchronous REST (HTTP + JSON)
- **Data:** Each service owns its own SQLite database (loose coupling)
- **Contracts:** Shared Pydantic models in `/shared`
- **Design patterns:** API Gateway not used (demo simplicity); Service-to-service calls; Repository pattern inside each service
- **Non-functional:** Basic API-key style auth can be added; CORS enabled for the demo UI; OpenAPI docs auto-generated

## GitHub Submission Notes

- Create a public/private repository.
- Push this entire folder.
- Every team member must have a GitHub account and be added as collaborator.
- Include this README and a short CONTRIBUTING.md if desired.
- Submit the repository URL + individual profile URLs as required by the assignment.

## Authors
[Add team member names and student numbers here]

---
*This is a teaching/demo implementation for CSC411. It is not production-ready.*
