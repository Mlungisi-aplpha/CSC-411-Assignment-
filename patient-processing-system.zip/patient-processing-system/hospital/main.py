"""
Hospital Service – Port 8001
Responsible for patient registration, consultations, ordering lab tests
and issuing prescriptions. Communicates with Laboratory and Pharmacy via REST.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List, Optional
import httpx

from database import init_db, get_db, PatientModel, ConsultationModel
from shared.models import (
    PatientCreate, Patient, ConsultationCreate, Consultation,
    LabOrderCreate, TestItem, PrescriptionCreate, MedicationItem,
    ConsultationStatus, ServiceResponse
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
LABORATORY_URL = os.getenv("LABORATORY_URL", "http://localhost:8002")
PHARMACY_URL = os.getenv("PHARMACY_URL", "http://localhost:8003")

app = FastAPI(
    title="Hospital Service",
    description="Patient registration, consultations, lab orders and prescriptions",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    init_db()


# ---------------------------------------------------------------------------
# Patient endpoints
# ---------------------------------------------------------------------------
@app.post("/patients", response_model=Patient, status_code=status.HTTP_201_CREATED)
def register_patient(patient: PatientCreate, db: Session = Depends(get_db)):
    db_patient = PatientModel(**patient.model_dump())
    db.add(db_patient)
    db.commit()
    db.refresh(db_patient)
    return db_patient


@app.get("/patients", response_model=List[Patient])
def list_patients(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    return db.query(PatientModel).offset(skip).limit(limit).all()


@app.get("/patients/{patient_id}", response_model=Patient)
def get_patient(patient_id: int, db: Session = Depends(get_db)):
    patient = db.query(PatientModel).filter(PatientModel.id == patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    return patient


# ---------------------------------------------------------------------------
# Consultation endpoints
# ---------------------------------------------------------------------------
@app.post("/consultations", response_model=Consultation, status_code=status.HTTP_201_CREATED)
def create_consultation(consultation: ConsultationCreate, db: Session = Depends(get_db)):
    # Verify patient exists
    patient = db.query(PatientModel).filter(PatientModel.id == consultation.patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db_consult = ConsultationModel(**consultation.model_dump())
    db.add(db_consult)
    db.commit()
    db.refresh(db_consult)
    return db_consult


@app.get("/consultations/{consultation_id}", response_model=Consultation)
def get_consultation(consultation_id: int, db: Session = Depends(get_db)):
    consult = db.query(ConsultationModel).filter(ConsultationModel.id == consultation_id).first()
    if not consult:
        raise HTTPException(status_code=404, detail="Consultation not found")
    return consult


@app.get("/consultations", response_model=List[Consultation])
def list_consultations(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    return db.query(ConsultationModel).offset(skip).limit(limit).all()


# ---------------------------------------------------------------------------
# Order Laboratory Tests (inter-service call)
# ---------------------------------------------------------------------------
@app.post("/consultations/{consultation_id}/order-tests", response_model=ServiceResponse)
async def order_lab_tests(
    consultation_id: int,
    tests: List[TestItem],
    ordered_by: str = "Dr. Unknown",
    priority: str = "normal",
    db: Session = Depends(get_db)
):
    consult = db.query(ConsultationModel).filter(ConsultationModel.id == consultation_id).first()
    if not consult:
        raise HTTPException(status_code=404, detail="Consultation not found")

    patient = db.query(PatientModel).filter(PatientModel.id == consult.patient_id).first()

    lab_order = LabOrderCreate(
        consultation_id=consultation_id,
        patient_id=consult.patient_id,
        patient_name=f"{patient.first_name} {patient.last_name}",
        tests=tests,
        ordered_by=ordered_by,
        priority=priority
    )

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            response = await client.post(
                f"{LABORATORY_URL}/orders",
                json=lab_order.model_dump()
            )
            response.raise_for_status()
            lab_data = response.json()
        except httpx.HTTPError as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Failed to reach Laboratory service: {exc}"
            )

    # Update consultation
    consult.lab_order_id = lab_data["id"]
    consult.status = ConsultationStatus.AWAITING_LAB.value
    consult.updated_at = datetime.utcnow()
    db.commit()

    return ServiceResponse(
        success=True,
        message="Laboratory tests ordered successfully",
        data=lab_data
    )


# ---------------------------------------------------------------------------
# Issue Prescription (inter-service call)
# ---------------------------------------------------------------------------
@app.post("/consultations/{consultation_id}/prescribe", response_model=ServiceResponse)
async def issue_prescription(
    consultation_id: int,
    medications: List[MedicationItem],
    prescribed_by: str = "Dr. Unknown",
    diagnosis: Optional[str] = None,
    db: Session = Depends(get_db)
):
    consult = db.query(ConsultationModel).filter(ConsultationModel.id == consultation_id).first()
    if not consult:
        raise HTTPException(status_code=404, detail="Consultation not found")

    patient = db.query(PatientModel).filter(PatientModel.id == consult.patient_id).first()

    prescription = PrescriptionCreate(
        consultation_id=consultation_id,
        patient_id=consult.patient_id,
        patient_name=f"{patient.first_name} {patient.last_name}",
        medications=medications,
        prescribed_by=prescribed_by,
        diagnosis=diagnosis
    )

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            response = await client.post(
                f"{PHARMACY_URL}/prescriptions",
                json=prescription.model_dump()
            )
            response.raise_for_status()
            pharm_data = response.json()
        except httpx.HTTPError as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Failed to reach Pharmacy service: {exc}"
            )

    # Update consultation
    consult.prescription_id = pharm_data["id"]
    consult.diagnosis = diagnosis
    consult.status = ConsultationStatus.PRESCRIBED.value
    consult.updated_at = datetime.utcnow()
    db.commit()

    return ServiceResponse(
        success=True,
        message="Prescription issued and sent to Pharmacy",
        data=pharm_data
    )


# ---------------------------------------------------------------------------
# Health & root
# ---------------------------------------------------------------------------
@app.get("/")
def root():
    return {
        "service": "Hospital Service",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
