#!/usr/bin/env bash
# Start all three services in the background (for demo convenience)
# Usage: ./scripts/start_all.sh

set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "Starting Hospital service on :8001 ..."
cd hospital
uvicorn main:app --host 0.0.0.0 --port 8001 --reload &
HOSP_PID=$!
cd ..

echo "Starting Laboratory service on :8002 ..."
cd laboratory
uvicorn main:app --host 0.0.0.0 --port 8002 --reload &
LAB_PID=$!
cd ..

echo "Starting Pharmacy service on :8003 ..."
cd pharmacy
uvicorn main:app --host 0.0.0.0 --port 8003 --reload &
PHARM_PID=$!
cd ..

echo ""
echo "Services started:"
echo "  Hospital   → http://localhost:8001/docs  (PID $HOSP_PID)"
echo "  Laboratory → http://localhost:8002/docs  (PID $LAB_PID)"
echo "  Pharmacy   → http://localhost:8003/docs  (PID $PHARM_PID)"
echo ""
echo "Demo UI: open client/index.html in your browser"
echo "Press Ctrl+C to stop all services"

trap "kill $HOSP_PID $LAB_PID $PHARM_PID 2>/dev/null" EXIT
wait
