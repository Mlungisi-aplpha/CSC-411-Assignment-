# System Architecture – Patient Processing System

## 1. Overview

The solution follows a **microservices architecture** in which each participating organisation is represented by an independent REST service:

| Service       | Organisation | Responsibility                              | Port |
|---------------|--------------|---------------------------------------------|------|
| Hospital      | Hospital     | Patient registry, consultations, orchestration | 8001 |
| Laboratory    | Laboratory   | Test order processing & result publishing   | 8002 |
| Pharmacy      | Pharmacy     | Prescription validation & dispensing        | 8003 |

Services communicate **synchronously over HTTP/JSON** (REST). There is no shared database; each service owns its own SQLite store (database-per-service pattern).

## 2. Component Diagram (textual)

```
┌─────────────┐         REST          ┌──────────────┐
│   Client    │ ────────────────────► │   Hospital   │
│  (Browser)  │                       │   :8001      │
└─────────────┘                       └──────┬───────┘
                                             │
                         ┌───────────────────┼───────────────────┐
                         │ REST              │ REST              │
                         ▼                   ▼                   ▼
                  ┌──────────────┐    ┌──────────────┐
                  │ Laboratory   │    │  Pharmacy    │
                  │   :8002      │    │   :8003      │
                  └──────────────┘    └──────────────┘
```

## 3. Key Design Decisions

- **Loose coupling**: Services only know each other’s public REST contracts (defined in `shared/models.py`).
- **Service autonomy**: Each service can be developed, deployed and scaled independently.
- **Synchronous REST**: Chosen for simplicity and clear request/response semantics suitable for a teaching demo. (In production one might add an event bus for the “lab results ready” notification.)
- **Pydantic contracts**: Shared models guarantee consistent JSON payloads.
- **OpenAPI**: Every service automatically exposes interactive documentation at `/docs`.

## 4. Design Patterns Used

| Pattern                    | Where applied                                      |
|---------------------------|----------------------------------------------------|
| API Resource              | All endpoints follow resource-oriented URLs        |
| Repository (lightweight)  | SQLAlchemy models + session helpers per service    |
| DTO / Contract            | Shared Pydantic models                             |
| Orchestration             | Hospital service coordinates the overall process   |
| Database-per-service      | Separate SQLite files                              |

## 5. Non-functional Requirements Addressed

- **Interoperability** – pure REST + JSON
- **Discoverability** – OpenAPI / Swagger UI
- **CORS** – enabled so the static demo UI can call the APIs
- **Observability (basic)** – health endpoints + structured log messages in the UI
- **Extensibility** – new organisations can be added as additional services that follow the same contract style

## 6. Future Improvements (for discussion in report)

- Replace synchronous polling with webhooks or a message broker for lab-result notification
- Add JWT or API-key authentication between services
- Introduce an API Gateway
- Persist audit logs of every inter-service call
- Containerise properly with multi-stage Docker builds and healthchecks
