from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

SQLALCHEMY_DATABASE_URL = "sqlite:///./pharmacy.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class PrescriptionModel(Base):
    __tablename__ = "prescriptions"

    id = Column(Integer, primary_key=True, index=True)
    consultation_id = Column(Integer, nullable=False)
    patient_id = Column(Integer, nullable=False)
    patient_name = Column(String, nullable=False)
    medications = Column(JSON, nullable=False)
    prescribed_by = Column(String, nullable=False)
    diagnosis = Column(Text, nullable=True)
    status = Column(String, default="received")
    created_at = Column(DateTime, default=datetime.utcnow)
    dispensed_at = Column(DateTime, nullable=True)


class StockModel(Base):
    __tablename__ = "stock"

    id = Column(Integer, primary_key=True, index=True)
    drug_code = Column(String, unique=True, nullable=False)
    drug_name = Column(String, nullable=False)
    quantity_available = Column(Integer, default=0)
    unit = Column(String, default="units")


def init_db():
    Base.metadata.create_all(bind=engine)

    # Seed some common medication stock if empty
    db = SessionLocal()
    try:
        if db.query(StockModel).count() == 0:
            sample_stock = [
                StockModel(drug_code="PARA500", drug_name="Paracetamol 500mg", quantity_available=500, unit="tablets"),
                StockModel(drug_code="AMOX250", drug_name="Amoxicillin 250mg", quantity_available=300, unit="capsules"),
                StockModel(drug_code="IBU400", drug_name="Ibuprofen 400mg", quantity_available=400, unit="tablets"),
                StockModel(drug_code="CETI10", drug_name="Cetirizine 10mg", quantity_available=200, unit="tablets"),
                StockModel(drug_code="OMEP20", drug_name="Omeprazole 20mg", quantity_available=150, unit="capsules"),
                StockModel(drug_code="METF500", drug_name="Metformin 500mg", quantity_available=350, unit="tablets"),
            ]
            db.add_all(sample_stock)
            db.commit()
    finally:
        db.close()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
