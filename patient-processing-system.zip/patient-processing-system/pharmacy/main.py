"""
Pharmacy Service – Port 8003
Receives prescriptions from Hospital, validates against stock,
and dispenses medication.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List, Optional

from database import init_db, get_db, PrescriptionModel, StockModel
from shared.models import (
    PrescriptionCreate, Prescription, PrescriptionStatus,
    ServiceResponse
)

app = FastAPI(
    title="Pharmacy Service",
    description="Receive prescriptions, check stock, dispense medication",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    init_db()


# ---------------------------------------------------------------------------
# Prescriptions
# ---------------------------------------------------------------------------
@app.post("/prescriptions", response_model=Prescription, status_code=status.HTTP_201_CREATED)
def receive_prescription(prescription: PrescriptionCreate, db: Session = Depends(get_db)):
    db_rx = PrescriptionModel(
        consultation_id=prescription.consultation_id,
        patient_id=prescription.patient_id,
        patient_name=prescription.patient_name,
        medications=[m.model_dump() for m in prescription.medications],
        prescribed_by=prescription.prescribed_by,
        diagnosis=prescription.diagnosis,
        status=PrescriptionStatus.RECEIVED.value
    )
    db.add(db_rx)
    db.commit()
    db.refresh(db_rx)

    return Prescription(
        id=db_rx.id,
        consultation_id=db_rx.consultation_id,
        patient_id=db_rx.patient_id,
        patient_name=db_rx.patient_name,
        medications=prescription.medications,
        prescribed_by=db_rx.prescribed_by,
        diagnosis=db_rx.diagnosis,
        status=PrescriptionStatus(db_rx.status),
        created_at=db_rx.created_at,
        dispensed_at=db_rx.dispensed_at
    )


@app.get("/prescriptions", response_model=List[Prescription])
def list_prescriptions(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    rows = db.query(PrescriptionModel).offset(skip).limit(limit).all()
    result = []
    for r in rows:
        result.append(Prescription(
            id=r.id,
            consultation_id=r.consultation_id,
            patient_id=r.patient_id,
            patient_name=r.patient_name,
            medications=r.medications,
            prescribed_by=r.prescribed_by,
            diagnosis=r.diagnosis,
            status=PrescriptionStatus(r.status),
            created_at=r.created_at,
            dispensed_at=r.dispensed_at
        ))
    return result


@app.get("/prescriptions/{rx_id}", response_model=Prescription)
def get_prescription(rx_id: int, db: Session = Depends(get_db)):
    r = db.query(PrescriptionModel).filter(PrescriptionModel.id == rx_id).first()
    if not r:
        raise HTTPException(status_code=404, detail="Prescription not found")
    return Prescription(
        id=r.id,
        consultation_id=r.consultation_id,
        patient_id=r.patient_id,
        patient_name=r.patient_name,
        medications=r.medications,
        prescribed_by=r.prescribed_by,
        diagnosis=r.diagnosis,
        status=PrescriptionStatus(r.status),
        created_at=r.created_at,
        dispensed_at=r.dispensed_at
    )


# ---------------------------------------------------------------------------
# Dispense
# ---------------------------------------------------------------------------
@app.post("/prescriptions/{rx_id}/dispense", response_model=ServiceResponse)
def dispense_prescription(rx_id: int, db: Session = Depends(get_db)):
    rx = db.query(PrescriptionModel).filter(PrescriptionModel.id == rx_id).first()
    if not rx:
        raise HTTPException(status_code=404, detail="Prescription not found")

    if rx.status == PrescriptionStatus.DISPENSED.value:
        raise HTTPException(status_code=400, detail="Prescription already dispensed")

    # Check stock for every medication
    shortages = []
    for med in rx.medications:
        stock = db.query(StockModel).filter(StockModel.drug_code == med["drug_code"]).first()
        if not stock:
            shortages.append(f"{med['drug_name']} ({med['drug_code']}) – not in formulary")
        elif stock.quantity_available < med["quantity"]:
            shortages.append(
                f"{med['drug_name']} – only {stock.quantity_available} available, need {med['quantity']}"
            )

    if shortages:
        rx.status = PrescriptionStatus.REJECTED.value
        db.commit()
        return ServiceResponse(
            success=False,
            message="Cannot dispense – stock issues",
            data={"shortages": shortages}
        )

    # Deduct stock
    for med in rx.medications:
        stock = db.query(StockModel).filter(StockModel.drug_code == med["drug_code"]).first()
        stock.quantity_available -= med["quantity"]

    rx.status = PrescriptionStatus.DISPENSED.value
    rx.dispensed_at = datetime.utcnow()
    db.commit()

    return ServiceResponse(
        success=True,
        message="Medication dispensed successfully",
        data={
            "prescription_id": rx.id,
            "status": rx.status,
            "dispensed_at": rx.dispensed_at.isoformat()
        }
    )


# ---------------------------------------------------------------------------
# Stock management (simple)
# ---------------------------------------------------------------------------
@app.get("/stock")
def get_stock(db: Session = Depends(get_db)):
    rows = db.query(StockModel).all()
    return [
        {
            "drug_code": r.drug_code,
            "drug_name": r.drug_name,
            "quantity_available": r.quantity_available,
            "unit": r.unit
        }
        for r in rows
    ]


@app.post("/stock/restock")
def restock(drug_code: str, quantity: int, db: Session = Depends(get_db)):
    stock = db.query(StockModel).filter(StockModel.drug_code == drug_code).first()
    if not stock:
        raise HTTPException(status_code=404, detail="Drug not found in formulary")
    stock.quantity_available += quantity
    db.commit()
    return {"message": f"Restocked {quantity} units of {stock.drug_name}", "new_qty": stock.quantity_available}


# ---------------------------------------------------------------------------
# Health & root
# ---------------------------------------------------------------------------
@app.get("/")
def root():
    return {
        "service": "Pharmacy Service",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
